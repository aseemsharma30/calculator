package com.finance.calculator.model.entity;

public class Account {
}
