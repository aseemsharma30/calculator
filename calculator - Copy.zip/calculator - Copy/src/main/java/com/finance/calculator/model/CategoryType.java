package com.finance.calculator.model;

public enum CategoryType {
    EMERGENCY_FUNDS,
    FIXED_DEPOSITS,
    LIFE_INSURANCE,
    PUBLIC_PROVIDENT_FUND,
    PROVIDENT_FUND,
    GOLD,
    SIP,
    BUYING_POWER,
    TRAVEL_ALLOWANCE,
    UNEXPECTED_FUNDS
}
