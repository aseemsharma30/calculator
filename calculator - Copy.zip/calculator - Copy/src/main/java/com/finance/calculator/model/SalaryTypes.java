package com.finance.calculator.model;

public enum SalaryTypes {
    MORE_THAN_30K,
    MORE_THAN_50K,
    MORE_THAN_70K,
    MORE_THAN_90K,
    MORE_THAN_120K
}
